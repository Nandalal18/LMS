package com.example.vignanlibrary;


import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.widget.EditText;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class ViewBooks extends AppCompatActivity {

    static DatabaseForLibrary handler;
    private ArrayList<Book> bookList = new ArrayList<>();
    private RecyclerView.Adapter<?> adapter;
    private RecyclerView rv;
    private EditText txtSearch;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_view_books);

        handler = new DatabaseForLibrary(this);
        viewBooks();

        txtSearch = findViewById(R.id.txtSearch);
        txtSearch.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                ArrayList<Book> filteredBook = new ArrayList<>();
                if (!txtSearch.getText().toString().isEmpty()) {
                    for (int i = 0; i < bookList.size(); i++) {
                        if (bookList.get(i).getBookName().toLowerCase().contains(s.toString().toLowerCase())) {
                            filteredBook.add(bookList.get(i));
                        }
                    }
                    adapter = new BookAdapter(ViewBooks.this, filteredBook);
                    rv.setAdapter(adapter);
                } else {
                    adapter = new BookAdapter(ViewBooks.this, bookList);
                    rv.setAdapter(adapter);
                }
            }

            @Override
            public void afterTextChanged(Editable s) {
            }
        });
    }

    private void viewBooks() {
        bookList = handler.viewAllBook(this);
        adapter = new BookAdapter(this, bookList);
        rv = findViewById(R.id.view);
        rv.setLayoutManager(new LinearLayoutManager(this, LinearLayoutManager.VERTICAL, false));
        rv.setAdapter(adapter);
    }

    @Override
    protected void onResume() {
        viewBooks();
        super.onResume();
    }
}
