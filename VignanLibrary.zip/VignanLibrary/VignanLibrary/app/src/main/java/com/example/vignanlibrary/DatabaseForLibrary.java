package com.example.vignanlibrary;


import android.annotation.SuppressLint;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

public class DatabaseForLibrary extends SQLiteOpenHelper {

    private static final String DATABASE_NAME = "LibraryManagament.db";
    private static final String TABLE_NAME = "LibraryTable";
    private static final String COL_1 = "ID";
    private static final String COL_2 = "USERNAME";
    private static final String COL_3 = "EMAIL";
    private static final String COL_4 = "PASSWORD";

    private static final String TABLE_USER = "UserTable";
    private static final String TABLE_BOOK = "Books";

    private static final String TABLE_RESERVATION = "Reservation";
    private static final String RESERVATION_ID = "reservationID";
    private static final String NAME = "FIRSTNAME";
    private static final String SURNAME = "SECONDNAME";
    private static final String STARTTIME = "StartTime";
    private static final String FinishTıme = "FinishTime";
    private static final String PHONE = "PHONE";

    private Context context;

    public DatabaseForLibrary(Context context) {
        super(context, DATABASE_NAME, null, 1);
        this.context = context;
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE IF NOT EXISTS " + TABLE_BOOK + " (ID INTEGER PRIMARY KEY AUTOINCREMENT, BOOKNAME VARCHAR(30), CATEGORY VARCHAR(20), AUTHOR VARCHAR(30), LOCATION VARCHAR(30), QUANTITY INTEGER)");
        db.execSQL("CREATE TABLE IF NOT EXISTS " + TABLE_USER + " (ID INTEGER PRIMARY KEY AUTOINCREMENT, USERNAME VARCHAR(30), PASSWORD VARCHAR(100), EMAIL VARCHAR(30), firstName VARCHAR(30), lastName VARCHAR(30) )");
        db.execSQL("CREATE TABLE IF NOT EXISTS " + TABLE_NAME + " (ID INTEGER PRIMARY KEY AUTOINCREMENT, USERNAME VARCHAR(30), EMAIL VARCHAR(100), PASSWORD VARCHAR(30) )");
        db.execSQL("CREATE TABLE IF NOT EXISTS " + TABLE_RESERVATION + " (" + RESERVATION_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " + NAME + " VARCHAR(30) NOT NULL, " + SURNAME + " VARCHAR(30) NOT NULL, " + STARTTIME + " LONG NOT NULL, " + FinishTıme + " LONG NOT NULL, " + PHONE + " VARCHAR(30) NOT NULL, " + COL_1 + " INTEGER NOT NULL)");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_NAME);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_USER);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_BOOK);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_RESERVATION);
        onCreate(db);
    }

    public boolean insertData(String username, String email, String password) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COL_2, username);
        values.put(COL_3, email);
        values.put(COL_4, password);
        long res = db.insert(TABLE_NAME, null, values);
        db.close();
        return res != -1;
    }

    public boolean insertUserData(String username, String password, String email, String firstName, String lastName) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put("USERNAME", username);
        values.put("PASSWORD", password);
        values.put("EMAIL", email);
        values.put("firstName", firstName);
        values.put("lastName", lastName);
        long res = db.insert("UserTable", null, values);
        db.close();
        return res != -1;
    }

    public void insertBook(Book book) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put("BOOKNAME", book.getBookName());
        values.put("CATEGORY", book.getCategory());
        values.put("AUTHOR", book.getAuthor());
        values.put("LOCATION", book.getLocation());
        values.put("Quantity", book.getQuantity());
        long res = db.insert("Books", null, values);

        if (res == -1) {
            Toast.makeText(context, "Failed", Toast.LENGTH_SHORT).show();
        } else {
            Toast.makeText(context, "Success", Toast.LENGTH_SHORT).show();
        }

        db.close();
    }

    public void insertReservation(String name, String surname, String startTime, String finishTime, String phone, String bookId) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(NAME, name);
        values.put(SURNAME, surname);
        values.put(STARTTIME, startTime);
        values.put(FinishTıme, finishTime);
        values.put(PHONE, phone);
        values.put(COL_1, bookId);
        long res = db.insert(TABLE_RESERVATION, null, values);

        if (res == -1) {
            Toast.makeText(context, "Failed", Toast.LENGTH_SHORT).show();
        } else {
            Toast.makeText(context, "Success", Toast.LENGTH_SHORT).show();
        }

        db.close();
    }

    @SuppressLint("Range")
    public List<Book> readData(int bookId) {
        List<Book> list = new ArrayList<>();
        SQLiteDatabase db = this.getReadableDatabase();
        String query = "SELECT * FROM " + TABLE_BOOK + " WHERE " + COL_1 + " = " + bookId;
        Cursor result = db.rawQuery(query, null);

        if (result.moveToFirst()) {
            do {
                Book book = new Book();
                book.setId(result.getInt(result.getColumnIndex("ID")));
                book.setBookName(result.getString(result.getColumnIndex("BOOKNAME")));
                book.setCategory(result.getString(result.getColumnIndex("CATEGORY")));
                book.setAuthor(result.getString(result.getColumnIndex("AUTHOR")));
                book.setLocation(result.getString(result.getColumnIndex("LOCATION")));
                book.setQuantity(result.getString(result.getColumnIndex("QUANTITY")));
                list.add(book);

            } while (result.moveToNext());
        }
        result.close();
        db.close();
        return list;
    }

    public boolean deleteBook(int bookId) {
        String query = "DELETE FROM " + TABLE_BOOK + " WHERE " + COL_1 + " = " + bookId;
        SQLiteDatabase db = this.getWritableDatabase();
        boolean result = false;
        try {
            db.execSQL(query);
            result = true;
        } catch (Exception e) {
            Log.e("DatabaseForLibrary", "Error While Deleting");
        }
        db.close();
        return result;
    }

    public boolean updateBook(String id, String bookName, String category, String author, String location, String quantity) {
        SQLiteDatabase db = this.getWritableDatabase();
        String query = "SELECT * FROM " + TABLE_BOOK;

        ContentValues contentValues = new ContentValues();
        contentValues.put("BOOKNAME", bookName);
        contentValues.put("CATEGORY", category);
        contentValues.put("AUTHOR", author);
        contentValues.put("LOCATION", location);
        contentValues.put("QUANTITY",quantity);
        boolean result = false;

        try {
            db.update(TABLE_BOOK, contentValues, COL_1 + " = ?", new String[]{id});
            result = true;
        } catch (Exception e) {
            Log.e("DatabaseForLibrary", "Error While Updating");
            result = false;
        }
        db.close();
        return result;
    }

    public boolean userPresent(String username, String password) {
        SQLiteDatabase db = getWritableDatabase();
        String query = "SELECT * FROM LibraryTable WHERE USERNAME = '" + username + "' AND PASSWORD = '" + password + "'";
        Cursor cursor = db.rawQuery(query, null);

        boolean result = false;
        if (cursor.getCount() > 0) {
            result = true;
        }

        cursor.close();
        db.close();
        return result;
    }

    public boolean userLibraryPresent(String username, String password) {
        SQLiteDatabase db = getWritableDatabase();
        String query = "SELECT * FROM UserTable WHERE USERNAME = '" + username + "' AND PASSWORD = '" + password + "'";
        Cursor cursor = db.rawQuery(query, null);

        boolean result = false;
        if (cursor.getCount() > 0) {
            result = true;
        }

        cursor.close();
        db.close();
        return result;
    }
    @SuppressLint("Range")
    public ArrayList<Book> viewAllBook(Context context) {
        SQLiteDatabase db = this.getReadableDatabase();
        String query = "SELECT * FROM " + TABLE_BOOK;
        Cursor data = db.rawQuery(query, null);
        ArrayList<Book> books = new ArrayList<>();

        if (data.getCount() == 0) {
            Toast.makeText(context, "No Records Found", Toast.LENGTH_SHORT).show();
        } else {
            data.moveToFirst();
            while (!data.isAfterLast()) {
                Book book = new Book();
                book.setId(data.getInt(data.getColumnIndex("ID")));
                book.setBookName(data.getString(data.getColumnIndex("BOOKNAME")));
                book.setCategory(data.getString(data.getColumnIndex("CATEGORY")));
                book.setAuthor(data.getString(data.getColumnIndex("AUTHOR")));
                book.setLocation(data.getString(data.getColumnIndex("LOCATION")));
                book.setQuantity(data.getString(data.getColumnIndex("QUANTITY")));
                books.add(book);
                data.moveToNext();
            }
            Toast.makeText(context, data.getCount() + " Records Found", Toast.LENGTH_SHORT).show();
        }

        data.close();
        db.close();
        return books;
    }
    @SuppressLint("Range")
    public List<Book> getAllBooks() {
        List<Book> lstBooks = new ArrayList<>();
        String selectAllQuery = "SELECT * FROM " + TABLE_BOOK;
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery(selectAllQuery, null);

        if (cursor.moveToFirst()) {
            do {
                Book book = new Book();
                book.setBookName(cursor.getString(cursor.getColumnIndex("BOOKNAME")));
                book.setCategory(cursor.getString(cursor.getColumnIndex("CATEGORY")));
                book.setAuthor(cursor.getString(cursor.getColumnIndex("AUTHOR")));
                book.setLocation(cursor.getString(cursor.getColumnIndex("LOCATION")));
                book.setQuantity(cursor.getString(cursor.getColumnIndex("QUANTITY")));
                lstBooks.add(book);
            } while (cursor.moveToNext());
        }

        cursor.close();
        db.close();
        return lstBooks;
    }


}


