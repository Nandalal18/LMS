package com.example.vignanlibrary;


import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;


public class ManageBook extends AppCompatActivity {

    private DatabaseForLibrary handler;
    private EditText txtName, txtSurname, txtStart, txtPhoneNo, txtQuantity;
    private Button buttonInsert;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_manage_book);

        handler = new DatabaseForLibrary(this);

        txtName = findViewById(R.id.txtName);
        txtSurname = findViewById(R.id.txtSurname);
        txtStart = findViewById(R.id.txtStart);
        txtPhoneNo = findViewById(R.id.txtPhoneNo);
        buttonInsert = findViewById(R.id.buttonInsert);
        txtQuantity = findViewById(R.id.txtquantity);

        buttonInsert.setOnClickListener(v -> {
            if (txtName.getText().toString().isEmpty() || txtSurname.getText().toString().isEmpty() || txtStart.getText().toString().isEmpty() || txtPhoneNo.getText().toString().isEmpty()) {
                Toast.makeText(this, "Please Fill All Areas", Toast.LENGTH_SHORT).show();
            } else {
                String bookName = txtName.getText().toString();
                String author = txtSurname.getText().toString();
                String category = txtStart.getText().toString();
                String location = txtPhoneNo.getText().toString();
                String quantity = txtQuantity.getText().toString();

                Book book = new Book(bookName, category, author, location, quantity);
                handler.insertBook(book);

                Toast.makeText(this, "Your Book Is Successfully Added.", Toast.LENGTH_SHORT).show();

                txtName.getText().clear();
                txtSurname.getText().clear();
                txtStart.getText().clear();
                txtPhoneNo.getText().clear();
                txtQuantity.getText().clear();
            }
        });
    }
}
