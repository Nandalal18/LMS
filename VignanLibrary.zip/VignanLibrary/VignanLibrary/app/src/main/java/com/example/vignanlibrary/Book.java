package com.example.vignanlibrary;

import java.util.Objects;

public class Book {
    private int id;
    private String bookName;
    private String category;
    private String author;
    private String location;
    private String quantity;

    public Book() {
    }

    public Book(String bookName, String category, String author, String location, String quantity) {
        this.bookName = bookName;
        this.category = category;
        this.author = author;
        this.location = location;
        this.quantity = quantity;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getBookName() {
        return bookName;
    }

    public void setBookName(String bookName) {
        this.bookName = bookName;
    }

    public String getCategory() {
        return category;
    }

    public void setCategory(String category) {
        this.category = category;
    }

    public String getAuthor() {
        return author;
    }

    public void setAuthor(String author) {
        this.author = author;
    }

    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location;
    }

    public String getQuantity() {
        return quantity;
    }

    public void setQuantity(String quantity) {
        this.quantity = quantity;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Book book = (Book) o;
        return id == book.id &&
                Objects.equals(bookName, book.bookName) &&
                Objects.equals(category, book.category) &&
                Objects.equals(author, book.author) &&
                Objects.equals(location, book.location) &&
                Objects.equals(quantity, book.quantity);
    }

    @Override
    public int hashCode() {
        return Objects.hash(id, bookName, category, author, location);
    }

    @Override
    public String toString() {
        return "Book{" +
                "id=" + id +
                ", bookName='" + bookName + '\'' +
                ", category='" + category + '\'' +
                ", author='" + author + '\'' +
                ", location='" + location + '\'' +
                ", quantity='" + quantity + '\'' +
                '}';
    }
}

