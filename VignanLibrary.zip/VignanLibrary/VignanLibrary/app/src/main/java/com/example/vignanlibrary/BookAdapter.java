package com.example.vignanlibrary;

import android.app.AlertDialog;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class BookAdapter extends RecyclerView.Adapter<BookAdapter.ViewHolder> {

    private Context context;
    private ArrayList<Book> books;

    public BookAdapter(Context context, ArrayList<Book> books) {
        this.context = context;
        this.books = books;
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        TextView labelId, labelName, labelAuthor, labelCategory, labelLocation,labelQunatity;
        Button btnUpdate, btnDelete;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            labelId = itemView.findViewById(R.id.txtReservationID);
            labelName = itemView.findViewById(R.id.txtName);
            labelAuthor = itemView.findViewById(R.id.txtSurname);
            labelCategory = itemView.findViewById(R.id.txtStart);
            labelLocation = itemView.findViewById(R.id.txtPhoneNo);
            labelQunatity = itemView.findViewById(R.id.txtquantity);
            btnUpdate = itemView.findViewById(R.id.btnUpdate);
            btnDelete = itemView.findViewById(R.id.btnDelete);
        }
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.book_info, parent, false);
        return new ViewHolder(v);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        Book book = books.get(position);
        holder.labelId.setText(String.valueOf(book.getId()));
        holder.labelName.setText(book.getBookName());
        holder.labelAuthor.setText(book.getAuthor());
        holder.labelCategory.setText(book.getCategory());
        holder.labelLocation.setText(book.getLocation());
        holder.labelQunatity.setText(book.getQuantity());


        holder.btnDelete.setOnClickListener(v -> {
            String bookName = book.getBookName();
            new AlertDialog.Builder(context)
                    .setTitle("Warning")
                    .setMessage("Are You Sure to Delete: " + bookName)
                    .setPositiveButton("Yes", (dialog, which) -> {
                        if (ViewBooks.handler.deleteBook(book.getId())) {
                            books.remove(book);
                            notifyItemRemoved(position);
                            notifyItemRangeChanged(position, books.size());
                            Toast.makeText(context, "Book " + bookName + " Deleted", Toast.LENGTH_SHORT).show();
                        } else {
                            Toast.makeText(context, "Error While Deleting", Toast.LENGTH_SHORT).show();
                        }
                    })
                    .setNegativeButton("No", (dialog, which) -> {
                    })
                    .setIcon(R.drawable.ic_warning_black_24dp).show();
        });

        holder.btnUpdate.setOnClickListener(v -> {
            LayoutInflater inflater = LayoutInflater.from(context);
            View view = inflater.inflate(R.layout.a, null);

            TextView txtEditBookName = view.findViewById(R.id.updateBookName);
            TextView txtEditCategory = view.findViewById(R.id.updateCategory);
            TextView txtEditAuthor = view.findViewById(R.id.updateAuthor);
            TextView txtEditLocation = view.findViewById(R.id.updateLocation);
            TextView txtEditQuantity = view.findViewById(R.id.updateQuantity);

            txtEditBookName.setText(book.getBookName());
            txtEditCategory.setText(book.getCategory());
            txtEditAuthor.setText(book.getAuthor());
            txtEditLocation.setText(book.getLocation());
            txtEditQuantity.setText(book.getQuantity());

            new AlertDialog.Builder(context)
                    .setTitle("Update Book Info")
                    .setView(view)
                    .setPositiveButton("Update", (dialog, which) -> {
                        boolean isUpdate = ViewBooks.handler.updateBook(
                                String.valueOf(book.getId()),
                                txtEditBookName.getText().toString(),
                                txtEditCategory.getText().toString(),
                                txtEditAuthor.getText().toString(),
                                txtEditLocation.getText().toString(),
                                txtEditQuantity.getText().toString());

                        if (isUpdate) {
                            book.setBookName(txtEditBookName.getText().toString());
                            book.setCategory(txtEditCategory.getText().toString());
                            book.setAuthor(txtEditAuthor.getText().toString());
                            book.setLocation(txtEditLocation.getText().toString());
                            book.setQuantity(txtEditQuantity.getText().toString());
                            notifyDataSetChanged();
                            Toast.makeText(context, "Update is successful", Toast.LENGTH_SHORT).show();
                        } else {
                            Toast.makeText(context, "Error While Updating", Toast.LENGTH_SHORT).show();
                        }
                    })
                    .setNegativeButton("Cancel", (dialog, which) -> {
                    })
                    .create()
                    .show();
        });
    }

    @Override
    public int getItemCount() {
        return books.size();
    }
}
